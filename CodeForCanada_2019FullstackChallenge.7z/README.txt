The following programs are for the CodeForCanada 2019 challenge.

I have used python 3 and pandas library to solve the challenges.

You would need to have pandas library installed to run the programs. To install pandas use - pip install pandas - in the shell prompt

Both the programs are neatly commented and are self contained.